@extends('admin.adminbase')

@section('content')
	<div class="alert alert-warning" role="alert">تحت الإنشاء</div>

@endsection