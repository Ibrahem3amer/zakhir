<!DOCTYPE html>
<html>
	<head>
		<title>Zakhir</title>
		<link rel="stylesheet" type="text/css" href="/css/product.css">
		<link rel="stylesheet" type="text/css" href="/css/style.css">
		<link rel="stylesheet" type="text/css" href="/css/bootstrap.css">
		<link rel="stylesheet" type="text/css" href="/css/font-awesome.css">
        <link rel="stylesheet" href="http://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
		<link rel="stylesheet" href="/fancybox/jquery.fancybox.css" type="text/css" media="screen" />
		<link rel="stylesheet" href="/deso/jquery.desoslide.css" />
        <script src="http://code.jquery.com/jquery-1.10.2.js"></script>
        <script src="http://code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
        <script type="text/javascript" src="/fancybox/jquery.fancybox.pack.js"></script>
        <script type="text/javascript" src="/deso/jquery.desoslide.min.js"></script>
        <script type="text/javascript" src="/js/bootstrap.min.js"></script>
		<script type="text/javascript">
			function addEventListenerList(list) {
			    for (var i = 0, len = list.length; i < len; i++) {
			        list[i].addEventListener('click', function(){
			        	document.getElementById('myframe').style.visibility = "visible";
			        	window.location.hash = '#myframe';
			        });
			    }
			}

			function display_details() {
				/*var btn = getElementById('right');
				btn.addEventListener('click', function (e) {
				    /*var d = window.parent.document;
				    var frame = d.getElementById('myframe');
				    frame.parentNode.removeChild(frame);
				    e.preventDefault();
				    alert('gaga');
				});*/
				var nodes = document.getElementsByClassName('right-item-btn');
				addEventListenerList(nodes);

				document.getElementById('close-btn').addEventListener("click", function(){
					document.getElementById('myframe').style.visibility = "hidden";
				});
			}

			$(document).ready(function () {

				$('#tags').keypress(function(){
					var value = $(this).val();
					$.ajax({
						url: '/public/users/search?query'+value,
						success: function(results)
						{
							$( "#tags" ).autocomplete({
			                        source: results
			              	});
	                        console.log(results);
						},
					});
				});
			});


		</script>
	</head>
	<body onload="display_details()">
		<div id="wrapper">
			<div class="container upper-header">
				<header>
					<div class="row">
						<div class="col-sm-12 col-md-2 col-lg-2">
							<img src="/img/Zakhir_ar_ok.jpg" width="100px" height="100px" class="">
						</div>
						<div class="col-sm-12 col-md-4 col-lg-4">
							<form action="/public/users/search" method="post">
							<input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
								<input type="text" id="tags" placeholder="search" class="form-control" name="search_query" />
							</form>
						</div>

						<div class="col-sm-12 col-md-6 col-lg-6">
							<div id="client_data">
								<ul class="nav nav-pills">
									@if( \Auth::check())
										<div id="cart" class="pull-right">
										  <li role="presentation" class="dropdown">
										    <a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
										     <span> سلة المشتريات </span>
										    </a>
										    <ul class="dropdown-menu">
										    	<?php $cart = \App\Cart::where('user_id', \Auth::user()->id)->where('active', 1)->get(); ?>
										    	@foreach( $cart as $product )
										    		<li>
										    			<?php $product = \App\Product::find($product->product_id); echo $product->name;?>
										    		</li>
										    		<hr />
										    	@endforeach

										    	<li><a href="{{ URL::to('/') }}/order/home">انهاء الطلب</a></li>
										    	<li><a href="{{ URL::to('/') }}/order/track">تابع طلباتك</a></li>

										    </ul>
										  </li>
										</div>
										<div id="profile" class="pull-right">
											<li role="presentation" class="dropdown">
											    <a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
											     <span> {{\Auth::user()->name}} </span>
											    </a>
											    <ul class="dropdown-menu">
										    		<li><a href="#">الملف الشخصي</a></li>
										    		<li><a href="#">تعديل البيانات</a></li>
										    		<!-- if admin -->
										    		<li><a href="{{ URL::to('/') }}/media/addmedia">أضف صورة</a></li>
										    		<li><a href="{{ URL::to('/') }}/product/addproduct	">أضف منتج</a></li>
										    		<!-- end if admin -->
										    		<li><a href="{{ URL::to('/') }}/cart/home">سلة الشراء</a></li>
										    		<li><a href="{{ URL::to('/') }}/cart/wishlist">قائمة الأمنيات</a></li>
										    		<li><a href="{{ URL::to('/') }}/users/signout">تسجيل الخروج</a></li>
											    </ul>
											  </li>
										</div>
									@else
										<div id="signin" class="pull-right">
										  <li>
										    <a href="{{ URL::to('/') }}/users/signin"><span>Sign in </span></a>
										  </li>
										</div>
										<div id="signup" class="pull-right">
										  <li>
										    <a href="{{ URL::to('/') }}/users/signup"><span> Sign Up</span></a>
										  </li>
										</div>

									@endif
								</ul> 
							</div>
						</div>
					</div>
					<br />
					<div class="row pull-right">
						<ul class="nav nav-pills" style="direction: rtl;">
							<li role="presentation" class="dropdown">
						    <a class="dropdown-toggle" href="{{ URL::to('/') }}/pages/team" role="button">
						     <span class="glyphicon glyphicon-list"><span> اتصل بنا </span></span>
						    </a>
						  </li>
						  <?php $categories = \App\Cat::all(); ?>
						  <li role="presentation" class="dropdown">
						    <a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
 						     <span class="glyphicon glyphicon-shopping-cart"><span> المنتجات </span></span>
						    </a>
						    <ul class="dropdown-menu">
						    	@foreach( $categories as $cat )
						    		<li class="pull-right">
							    		<a href="{{ URL::to('/') }}/product/cat/{{ $cat->id }}" class="fa fa-hand-o-left"> {{ $cat->name }}
							    		</a>
							    	</li>
							    @endforeach
						    </ul>
						  </li>
						  <?php $albums = \App\Album::all(); ?>
						  <li role="presentation" class="dropdown">
						    <a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
						    <span class="glyphicon glyphicon-camera"><span> ألبوم الصور </span> 
						    </a>
						    <ul class="dropdown-menu">
						    	@foreach( $albums as $cat )
						    		<li class="pull-right">
							    		<a href="{{ URL::to('/') }}/media/album/{{ $cat->id }}" class="fa fa-hand-o-left"> {{ $cat->name }}
							    		</a>
							    	</li>
							    @endforeach
						    </ul>
						  </li>
						  <li role="presentation" class="dropdown">
						    <a class="dropdown-toggle" href="{{ URL::to('/') }}/pages/team" role="button">
						     <span class="glyphicon glyphicon-list"><span> عن زاخر </span></span>
						    </a>
						  </li>
  						  <li role="presentation" class="dropdown">
						    <a class="dropdown-toggle" href="{{ URL::to('/') }}/pages/team" role="button">
						     <span class="glyphicon glyphicon-list"><span> فريق العمل </span></span>
						    </a>
						  </li>
  						  <li role="presentation" class="dropdown">
						    <a class="dropdown-toggle" href="{{ URL::to('/') }}/pages/team" role="button">
						     <span class="glyphicon glyphicon-list"><span> اسألني </span></span>
						    </a>
						  </li>
						  <li role="presentation" class="dropdown">
						    <a class="dropdown-toggle" href="{{ URL::to('/') }}" role="button">
						     <span class="glyphicon glyphicon-list"><span> الرئيسية </span></span>
						    </a>
						  </li>
						</ul>
					</div>

				</header>	
			</div>
			<hr style="color: #27ae60;" class="container" />	
			<br /> 
			<div class="container">
				@yield('body')	
			</div>
			<footer>
				<P>All rights reserved</P>
			</footer>

		</div>
	</body>
</html>