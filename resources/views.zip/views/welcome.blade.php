@extends('layouts.base')

@section('body')
    @if( !isset($error) )
      <?php $error = "home"; ?>
    @endif
    @if( "home" === $error )
      
    @elseif( "" !== $error )
      <div class="alert alert-danger">{{$error}}</div>
    @else
      <div class="alert alert-success">You've Successfully completed your order! Thanks for using Zakhir.</div>
    @endif
    <?php $products = \App\Product::all()->sortByDesc('created_at'); $len = sizeof($products); $len<30?:$products = $products->slice(0, 29); ?>
    <div class="row">
        @foreach( $products as $product )
        <div class="col-sm-6 col-md-4 col-lg-4 prod">
            <div class="thumbnail">
              <input type="hidden" value="{{$product->id}}" class="product_id" />
              <input type="hidden" value="{{$product->photo_url}}" class="photo_url" />
              <div class="thumb-hover" id="thumb-wrap" style="padding-top: 70%; padding-left: 10px; padding-right: 10px; background-image: url({{$product->photo_url}});"> 
                <div class="btn-group btn-group-justified thumb-options" role="group" aria-label="data" >
                  <div class="btn-group" role="group">
                    <a class="fancybox clickable grab_info" href="#prod_view"><button type="button" class="btn btn-default">تفاصيل</button></a>
                  </div>
                </div>
              </div>
              <div class="caption">
                <h3 class="product_name"><span class="fa fa-cart-arrow-down"></span> {{$product->name}}</h3>
                <h5 class="product_price">{{$product->price}}$</h5>
                <hr />  
                <p> {{$product->description}}</p>
                <p>
                    <?php 
                      /*$timestamp = new \Carbon($product->created_at);
                      $now = \Carbon::now();
                      echo $timestamp->diff($now);
                      $splitTimeStamp = explode(" ",$timestamp);
                      $date = $splitTimeStamp[0];
*/                      ?>
                    <small class="pull-left">{{$product->days()>0?$product->days()." days ago":"just today"}}</small>
                    <small class="pull-right">1.3K views</small>
                    <br />
                </p>
              </div>
            </div>
        </div>
        @endforeach
    </div>
    <div id="prod_view" style="display: none;">
      <table>
        <tr>
          <td width="50%">
          <img src="" class="box_img" width="300px" height="300px" />
          </td>
          <td width="50%" style="margin: 5px;">
            <h2 class="box_title"></h2>
            <h3 class="box_price">price</h3>
            <select name="prod_quantity" class="quan">
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
              <option value="4">4</option>
            </select>
            <button class="btn btn-primary to_cart">Add to cart</button>
          </td>
        </tr>
      </table>
    </div>
    <div class="pop-up-details" id="myframe">
    <div id="toolbar">
        <div class="pull-right" id="close-btn">
            <span><a href="#" id="x-btn">X</a></span>
        </div>
    </div>
    <iframe src="page.html" width="100%" height="100%">
    </iframe>
    </div>
    <script type="text/javascript">
      $('.fancybox').fancybox({
        openEffect  : 'elastic',
          closeEffect : 'elastic',
          helpers : {
            title : {
              type : 'over'
            }
          }
      });
      $('.grab_info').click(function(){
        prod = $(this).closest('.prod');
        //alert(prod);
        img = prod.find('.photo_url');
        title = prod.find('.product_name');
        price = prod.find('.product_price');
        id = prod.find('.product_id').val();

        box_title = $('.box_title');
        box_title.text(title.text());

        box_img = $('.box_img');
        box_img.attr('src', img.val());

        box_price = $('.box_price');
        box_price.text(price.text());

        $('.to_cart').click(function(){
          /*var newURL = window.location.protocol + "//" + window.location.host;
          window.location.href = newURL + '/cart/home';*/
          var prod_quantity = $('.quan').val();
          var user_id = 1/*$('.user_id').val()*/;
          $.ajax({
            url: "/public/cart/new?prod_id="+id+"&q="+prod_quantity+"&user="+user_id,
            success: function(){
              alert('added!');
            },
            error: function(){
              alert('failure');
              var newURL = window.location.protocol + "//" + window.location.host;
		window.location.href = newURL + '/users/signin';
            }
          });
        });
      });
    </script>
@endsection