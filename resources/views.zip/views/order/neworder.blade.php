@extends('layouts.base')

@section('body')
	<div class="container">
		<div class="col-md-6">
			<input type="hidden" class="user_id" value="1" />
			<ul>
				<?php $i = sizeof($products_in_cart)-1;?>
				<?php $sum = 0; ?>
				@foreach( $products as $product )
				<li class="" style="list-style-type: none;">
					<input type="hidden" class="prod_id" value="{{$product->id}}" />
					<img src="{{$product['photo_url']}}" class="responsive-img" width="70px" height="70px" />
					<span>{{$product['name']}}</span>
					<div class="badge">{{$products_in_cart[$i]->quantity}}</div>
					<hr />
					<?php $sum+= $product->price * $products_in_cart[$i--]->quantity; ?>
				</li>
				@endforeach
			</ul>
			<input type="hidden" id="total_cost" value="{{$sum}}" />
		</div>
		<div class="col-md-6">
			<h1>Your total cost is: {{$sum}}$</h1>
			<p>Saved address to be displayed here:Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>
			<button class="btn btn-success billing">Go to Billing</button>
			<button class="btn btn-danger cart">Back to cart</button>
		</div>
		<script type="text/javascript">
			$('.billing').click(function(){
				var newURL = window.location.protocol + "//" + window.location.host;
				user_id = $('.user_id').val();
				total = $('#total_cost').val();
	        	window.location.href = newURL + '/public/order/billing?user_id='+user_id+'&total='+total;
			});

			$('.cart').click(function(){
				var newURL = window.location.protocol + "//" + window.location.host;
	        	window.location.href = newURL + '/public/cart/home';
			});

		</script>
	</div>
@endsection