<?php $__env->startSection('body'); ?>
	<div class="container">
		<?php echo Form::open(['url'=>'media/addmedia','method'=>'POST', 'files'=>true]); ?>

			<label for="img_name">Name</label>
			<input type="input" placeholder="your image name" name="img_name" />
			<br />
			<label for="upload">upload</label>
			<input type="file" placeholder="your image name" name="upload" />
		  	<p class="errors"><?php echo $errors->first('upload'); ?></p> 
			<?php if(Session::has('error')): ?>
			<p class="errors"><?php echo Session::get('error'); ?></p>
			<?php endif; ?>
			<br />
			<label for="cats">Select a category</label>
		 	<select name="albums">
		 	<?php foreach( $albums as $album ): ?>
		  		<option value="<?php echo e($album->id); ?>"><?php echo e($album->name); ?></option>
	  		<?php endforeach; ?>
			</select> 
			<br />
			<input type="submit" value="Upload" />
		<?php echo Form::close(); ?>

	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>